# HTML SEMANTICS(Recreating a design using Html)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aeyjay/pen/RwQVrXw](https://codepen.io/Aeyjay/pen/RwQVrXw).

