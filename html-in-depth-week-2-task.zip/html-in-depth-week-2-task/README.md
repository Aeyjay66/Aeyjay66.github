# HTML In-Depth (Week 2 Task)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aeyjay/pen/poVZQGK](https://codepen.io/Aeyjay/pen/poVZQGK).

